﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpApplication.EntityModel
{
    public class EmpMaster
    {
        public int EmpCode { get; set; }
        public string EmpName { get; set; }
        public DateTime EmpDob { get; set; }
        public string Empgender { get; set; }
        public string EmpDepartment { get; set; }
        public string EmpDesignation { get; set; }
    }
}
