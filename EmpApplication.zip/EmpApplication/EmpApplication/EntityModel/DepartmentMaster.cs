﻿using System;


namespace EmpApplication.EntityModel
{
    public class DepartmentMaster
    {
        public string EmpDepartment { get; set; }
        public string EmpDesignation { get; set; }
    }
}
