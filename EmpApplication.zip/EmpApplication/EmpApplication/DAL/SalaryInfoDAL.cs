﻿using System;
using System.Data;
using System.Data.SqlClient;
using EmpApplication.EntityModel;
using EmpApplication.DAL;


namespace EmpApplication.DAL
{
    class SalaryInfoDAL
    {
       
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public int Savesalary(SalaryInfo sal)
        {
            int No = 0;
            try
            {
               
                cmd.Connection = sqlcon;
                cmd.CommandText = "SaveSalary";
                //cmd.CommandText = "insert into SalaryInfo(EmpCode,DataOfSalary,Basic,Hra,Da) " +
                //    "Values(" + sal.EmpCode+",'"+sal.DateOfSalary+"',"+sal.Basic+","+sal.Hra+","+sal.Da+")";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = sal.EmpCode;
                cmd.Parameters.Add("@DateOfSalary", SqlDbType.DateTime).Value = sal.DateOfSalary;
                cmd.Parameters.Add("@Basic", SqlDbType.Decimal).Value = sal.Basic;
                cmd.Parameters.Add("@Hra", SqlDbType.Int).Value = sal.Hra;
                cmd.Parameters.Add("@Da", SqlDbType.Int).Value = sal.Da;
                cmd.Parameters.Add("@SalarySheetNo", SqlDbType.Int).Direction = ParameterDirection.Output;
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                No=Convert.ToInt32(cmd.Parameters["@SalarySheetNo"].Value);
                return No;

            }
            catch(Exception ex)
            {
                return No;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public double Sumofsalary(int EmpCode)
        {
            double sumofbasic = 0;
            try
            {

                cmd.Connection = sqlcon;
                cmd.CommandText = "SumOfBasic";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = EmpCode;
                cmd.Parameters.Add("@Sum", SqlDbType.Decimal).Direction = ParameterDirection.Output;
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                sumofbasic= Convert.ToDouble(cmd.Parameters["@Sum"].Value);
                return sumofbasic;
            }
            catch(SqlException ex)
            {
                return sumofbasic;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool DeleteSalary(int SalarySheetNO)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "Delete from SalaryInfo where SalarySheetNO =" + SalarySheetNO + "";
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;

            }
            catch (SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

    }
}
