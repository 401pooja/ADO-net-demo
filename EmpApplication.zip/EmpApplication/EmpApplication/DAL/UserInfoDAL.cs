﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using EmpApplication.EntityModel;
namespace EmpApplication.DAL
{
   class UserInfoDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public bool IsValidUser(string username,string password)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select * from UserInfo where UserName='" + username.Trim() + "'and Password='" + password.Trim() + "'";
                if(sqlcon.State==System.Data.ConnectionState.Closed)
                {
                    sqlcon.Open();

                }
                dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    return true;
                }
                else
                {
                    return false;
                }
                
            }
            catch(Exception ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }
}
