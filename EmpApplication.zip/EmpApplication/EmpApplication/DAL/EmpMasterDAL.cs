﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using EmpApplication.EntityModel;
using EmpApplication.DAL;

namespace EmpApplication.DAL
{
    class EmpMasterDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public bool SaveEmployee(EmpMaster emp)
        {
            try
            {
                cmd.Connection = sqlcon;

                //cmd.CommandText = "insert into EmpMaster values(" + emp.EmpCode + ",'" + emp.EmpName + "','" + emp.EmpDob + "','" + emp.Empgender + "','" + emp.EmpDepartment + "','" + emp.EmpDesignation + "')";
                cmd.CommandText = "SaveEmployee";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = emp.EmpCode;
                cmd.Parameters.Add("@EmpName", SqlDbType.NVarChar).Value = emp.EmpName;
                cmd.Parameters.Add("@EmpDob", SqlDbType.DateTime).Value = emp.EmpDob;
                cmd.Parameters.Add("@EmpGender", SqlDbType.NVarChar).Value = emp.Empgender;
                cmd.Parameters.Add("@EmpDepartment", SqlDbType.NVarChar).Value = emp.EmpDepartment;
                cmd.Parameters.Add("@EmpDesignation", SqlDbType.NVarChar).Value = emp.EmpDesignation;
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool DeleteEmployee(int EmpCode)
        {
            try
            {
                cmd.Connection = sqlcon;
                // cmd.CommandText = "Delete from EmpMaster where EmpCode =" + EmpCode + "";
                cmd.CommandText = "DeleteEmployee";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = EmpCode;
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;

            }
            catch (SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool UpdateEmployee(EmpMaster emp1)
        {
            try
            {
                cmd.Connection = sqlcon;
                //cmd.CommandText = "update EmpMaster set EmpName='" + emp1.EmpName + "',EmpDob='" + emp1.EmpDob + "',EmpGender='" + emp1.Empgender + "',EmpDepartment='" + emp1.EmpDepartment + "',EmpDesignation='" + emp1.EmpDesignation + "'  where EmpCode=" + emp1.EmpCode + "";
                cmd.CommandText = "UpdateEmployee";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = emp1.EmpCode;
                cmd.Parameters.Add("@EmpName", SqlDbType.NVarChar).Value = emp1.EmpName;
                cmd.Parameters.Add("@EmpDob", SqlDbType.DateTime).Value = emp1.EmpDob;
                cmd.Parameters.Add("@EmpGender", SqlDbType.NVarChar).Value = emp1.Empgender;
                cmd.Parameters.Add("@EmpDepartment", SqlDbType.NVarChar).Value = emp1.EmpDepartment;
                cmd.Parameters.Add("@EmpDesignation", SqlDbType.NVarChar).Value = emp1.EmpDesignation;
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }

        }

        public EmpMaster ViewEmployee(int EmpCode)
        {
            EmpMaster emp = new EmpMaster();
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select * from EmpMaster where EmpCode=" + EmpCode + "";
                if(sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
              dr=  cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    dr.Read();
                    emp.EmpCode = Convert.ToInt32(dr["EmpCode"]);
                    emp.EmpName = dr["EmpName"].ToString();
                    emp.EmpDob = Convert.ToDateTime(dr["EmpDob"]);
                    emp.Empgender = dr["Empgender"].ToString();
                    emp.EmpDepartment = dr["EmpDepartment"].ToString();
                    emp.EmpDesignation = dr["EmpDesignation"].ToString();
                }
                dr.Close();
                return emp;
            }
            catch(Exception ex)
            {
                return emp;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public List<EmpMaster> ViewAllEmployee()
        {
            List<EmpMaster> emplist = new List<EmpMaster>();
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select * from EmpMaster";
                if(sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    while(dr.Read())
                    {
                        EmpMaster emp = new EmpMaster();
                        emp.EmpCode = Convert.ToInt32(dr["EmpCode"]);
                        emp.EmpName = dr["EmpName"].ToString();
                        emp.EmpDob = Convert.ToDateTime(dr["EmpDob"]);
                        emp.Empgender = dr["Empgender"].ToString();
                        emp.EmpDepartment = dr["EmpDepartment"].ToString();
                        emp.EmpDesignation = dr["EmpDesignation"].ToString();
                        emplist.Add(emp);


                    }
                }
                dr.Close();
                return emplist;
            }
            catch(Exception ex)
            {
                return emplist;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public int AutoEmpCode()
        {
            int empcode = 1;
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select Max(EmpCode) from EmpMaster";
                if(sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                empcode = Convert.ToInt32(cmd.ExecuteScalar());
                empcode++;
                return empcode;

            }
            catch(SqlException ex)
            {
                return empcode;
            }
            finally
            {
                sqlcon.Close();
            }
        }

    }
}



