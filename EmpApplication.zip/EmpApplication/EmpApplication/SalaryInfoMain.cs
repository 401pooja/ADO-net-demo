﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DAL;
using EmpApplication.EntityModel;


namespace EmpApplication
{
    class SalaryInfoMain
    {
        static void Main()
        {
            SalaryInfoDAL saldal = new SalaryInfoDAL();
            UserInfoDAL user = new UserInfoDAL();
            //Console.WriteLine("Enter username");
            //string username = Console.ReadLine();
            //Console.WriteLine("Enter password");
            //string password = Console.ReadLine();
            bool flag = user.IsValidUser("admin", "admin123");
            if (flag)
            {
                Console.WriteLine("Enter 1.Sumofbasic 2.save SalaryInfo 3.Delete Salary 3.SalaryInfo");
                int ResNo = Convert.ToInt32(Console.ReadLine());
                switch (ResNo)
                {
                    case 1:
                        #region Sumofbasic
                        //SalaryInfo s = new SalaryInfo();
                        Console.WriteLine("Enter EmpCode");
                        int EmpCode = Convert.ToInt32(Console.ReadLine());
                        
                        Console.WriteLine($"Sum of basic salary:{saldal.Sumofsalary(EmpCode)}");
                        #endregion
                        break;
                    case 2:
                        #region Save SalaryInfo
                        SalaryInfo sal = new SalaryInfo() { EmpCode = 2, DateOfSalary = Convert.ToDateTime("1980-02-01"), Basic = 500, Da = 100, Hra = 200 };
                        if (saldal.Savesalary(sal)>0)
                        {
                            Console.WriteLine($"Salary sheet:{sal.EmpCode}");
                        }
                        else
                        {
                            Console.WriteLine("Error occured");
                        }
                        #endregion
                        break;
                    case 3:
                        #region Delete Salary
                        int SalarySheetNO = 9;
                        if (saldal.DeleteSalary(SalarySheetNO))
                        {
                            Console.WriteLine($"Employee {SalarySheetNO} is deleted");
                        }
                        else
                        {
                            Console.WriteLine("Employee is not deleted");
                        }
                        #endregion
                        break;

                }
            }
            else
            {
                Console.WriteLine("Incorrect username and password");
            }
            Console.ReadLine();
        }
    }
}
