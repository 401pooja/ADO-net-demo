﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //EmpMasterDAL empdal = new EmpMasterDAL();
            //EmpMaster emp = new EmpMaster() { EmpCode = 1, EmpName = "scott", EmpDob = Convert.ToDateTime("1980-02-01"), Empgender = "male", EmpDepartment = "sales", EmpDesignation = "manager" };
            //if (empdal.SaveEmployee(emp))
            //{
            //    Console.WriteLine("Employee inforation saved");
            //}
            //else
            //{
            //    Console.WriteLine("Error occured");
            //}
            //Console.ReadLine();
            //DepartmentMasterDAL Deptdal = new DepartmentMasterDAL();
            //DepartmentMaster dept = new DepartmentMaster() { EmpDepartment = "production", EmpDesignation="manager"};
            //if (Deptdal.SaveEmployee(dept))
            //{
            //    Console.WriteLine("Employee inforation saved");
            //}
            //else
            //{
            //    Console.WriteLine("Error occured");
            //}
            //Console.ReadLine();

            EmpMasterDAL empdal = new EmpMasterDAL();
            UserInfoDAL user = new UserInfoDAL();
            Console.WriteLine("Enter username");
            string username = Console.ReadLine();
            Console.WriteLine("Enter password");
            string password = Console.ReadLine();
            bool flag = user.IsValidUser(username,password);
           // bool flag=user.IsValidUser("Admin", "admin123");
            if (flag)
            {
                Console.WriteLine("Enter 1.save Employee 2.Delete Employee 3.Update Employee 4.View Employee 5.View All Employees");
                int ResNo = Convert.ToInt32(Console.ReadLine());
                switch (ResNo)
                {
                    case 1:
                        #region Save Employee
                        EmpMaster emp = new EmpMaster() { EmpCode = empdal.AutoEmpCode(), EmpName = "scott", EmpDob = Convert.ToDateTime("1980-02-01"), Empgender = "male", EmpDepartment = "sales", EmpDesignation = "manager" };
                        if (empdal.SaveEmployee(emp))
                        {
                            Console.WriteLine("Employee inforation saved");
                        }
                        else
                        {
                            Console.WriteLine("Error occured");
                        }
                        #endregion
                        break;
                    case 2:
                        #region Delete Employee
                        int EmpCode = 1;
                        if (empdal.DeleteEmployee(EmpCode))
                        {
                            Console.WriteLine($"Employee {EmpCode} is deleted");
                        }
                        else
                        {
                            Console.WriteLine("Employee is not deleted");
                        }
                        #endregion
                        break;
                    case 3:
                        #region Update Employee

                        EmpMaster emp1 = new EmpMaster()
                        {
                            EmpCode = 1,
                            EmpName = "scott123",
                            EmpDob = Convert.ToDateTime("1993-02-01"),
                            Empgender = "male",
                            EmpDepartment = "sales",
                            EmpDesignation = "manager"
                        };
                        if (empdal.UpdateEmployee(emp1))
                        {
                            Console.WriteLine("Employee information updated");
                        }
                        else
                        {
                            Console.WriteLine("Not updated");
                        }

                        break;
                    #endregion
                    case 4:
                        #region View Employee
                        EmpMaster viewemp = empdal.ViewEmployee(1);
                        if (viewemp != null)
                        {
                            Console.WriteLine($"{viewemp.EmpCode}\t{viewemp.EmpDob.ToString("dd-mmm-yyyy")}\t{viewemp.EmpDepartment}\t{viewemp.Empgender}\t{viewemp.EmpDepartment}");
                        }
                        else
                        {
                            Console.WriteLine("Emp information not view");
                        }
                        break;
                    #endregion
                    case 5:
                        #region View All Employee
                        List<EmpMaster> emplist=empdal.ViewAllEmployee();
                        if(emplist.Count>0)
                        {
                            foreach(var temp in emplist)
                            {
                                Console.WriteLine($"{temp.EmpCode}\t{temp.EmpName}\t{temp.EmpDob}\t{temp.Empgender}\t{temp.EmpDepartment}\t{temp.EmpDesignation}");
                            }
                        }
                        else
                        {
                            Console.WriteLine("There is no employees");
                        }
                        break;

                        #endregion
                }
            }
            else
            {
                Console.WriteLine("Incorrect username or password");
            }
            Console.ReadLine();
        }

    }
}
